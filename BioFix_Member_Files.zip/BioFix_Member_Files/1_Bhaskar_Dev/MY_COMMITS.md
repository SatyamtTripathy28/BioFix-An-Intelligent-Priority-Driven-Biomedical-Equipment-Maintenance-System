# Bhaskar Dev: what to commit

Copy the files in this folder into your cloned `BioFix` folder, keeping the sub-folder names (`src/`, `data/`, `tests/`). The full guide is in `COMMIT_GUIDE.md`.

## Step 1: main

First. This is the very first push to the empty repository.

Commit 1: `Set up project: Makefile and .gitignore`
- `Makefile`
- `.gitignore`

Commit 2: `Add Equipment base class and three subclasses`
- `src/Equipment.h`
- `src/Equipment.cpp`

```
git clone https://github.com/YOUR-USERNAME/BioFix.git
cd BioFix
# copy the files from your folder into this BioFix folder (keep the folder names)
git add Makefile .gitignore
git commit -m "Set up project: Makefile and .gitignore"
git add src/Equipment.h src/Equipment.cpp
git commit -m "Add Equipment base class and three subclasses"
git branch -M main
git push -u origin main
```

## Step 5: feature/main-menu

After steps 3 and 4 are merged.

Commit 1: `Add main menu and connect all modules`
- `src/main.cpp`

```
git clone https://github.com/YOUR-USERNAME/BioFix.git     # skip if you already cloned it
cd BioFix
git checkout main
git pull
git checkout -b feature/main-menu
# copy the files from your folder into this BioFix folder (keep the folder names)
git add src/main.cpp
git commit -m "Add main menu and connect all modules"
git push -u origin feature/main-menu
```
