# Satyam Tripathy: what to commit

Copy the files in this folder into your cloned `BioFix` folder, keeping the sub-folder names (`src/`, `data/`, `tests/`). The full guide is in `COMMIT_GUIDE.md`.

## Step 2: feature/equipment-list-and-files

After step 1.

Commit 1: `Add EquipmentList, a singly linked list of equipment`
- `src/EquipmentList.h`

Commit 2: `Add file loading and saving with department file sync, plus sample data`
- `src/FileManager.h`
- `src/FileManager.cpp`
- `data/equipment.txt`
- `data/maintenance.txt`
- `data/radiology.txt`
- `data/icu.txt`
- `data/cardiology.txt`
- `data/operation_theatre.txt`
- `data/laboratory.txt`
- `data/emergency.txt`

Commit 3: `Add add, update, delete and department view screens`
- `src/EquipmentMenu.h`
- `src/EquipmentMenu.cpp`

Commit 4: `Add README with build and run steps`
- `README.md`

```
git clone https://github.com/YOUR-USERNAME/BioFix.git     # skip if you already cloned it
cd BioFix
git checkout main
git pull
git checkout -b feature/equipment-list-and-files
# copy the files from your folder into this BioFix folder (keep the folder names)
git add src/EquipmentList.h
git commit -m "Add EquipmentList, a singly linked list of equipment"
git add src/FileManager.h src/FileManager.cpp data/
git commit -m "Add file loading and saving with department file sync, plus sample data"
git add src/EquipmentMenu.h src/EquipmentMenu.cpp
git commit -m "Add add, update, delete and department view screens"
git add README.md
git commit -m "Add README with build and run steps"
git push -u origin feature/equipment-list-and-files
```
