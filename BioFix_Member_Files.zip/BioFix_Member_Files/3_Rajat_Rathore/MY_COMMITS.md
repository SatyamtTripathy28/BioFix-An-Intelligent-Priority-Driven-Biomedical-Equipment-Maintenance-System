# Rajat Rathore: what to commit

Copy the files in this folder into your cloned `BioFix` folder, keeping the sub-folder names (`src/`, `data/`, `tests/`). The full guide is in `COMMIT_GUIDE.md`.

## Step 3: feature/maintenance-queue

After step 2 is merged. Can happen at the same time as step 4.

Commit 1: `Add MaintenanceQueue, a linked queue of maintenance requests`
- `src/MaintenanceQueue.h`

Commit 2: `Add maintenance file saving and loading, schedule and process options`
- `src/MaintenanceManager.h`
- `src/MaintenanceManager.cpp`

```
git clone https://github.com/YOUR-USERNAME/BioFix.git     # skip if you already cloned it
cd BioFix
git checkout main
git pull
git checkout -b feature/maintenance-queue
# copy the files from your folder into this BioFix folder (keep the folder names)
git add src/MaintenanceQueue.h
git commit -m "Add MaintenanceQueue, a linked queue of maintenance requests"
git add src/MaintenanceManager.h src/MaintenanceManager.cpp
git commit -m "Add maintenance file saving and loading, schedule and process options"
git push -u origin feature/maintenance-queue
```
