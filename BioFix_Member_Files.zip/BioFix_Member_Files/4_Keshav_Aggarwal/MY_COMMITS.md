# Keshav Aggarwal: what to commit

Copy the files in this folder into your cloned `BioFix` folder, keeping the sub-folder names (`src/`, `data/`, `tests/`). The full guide is in `COMMIT_GUIDE.md`.

## Step 4: feature/search-sort

After step 2 is merged. Can happen at the same time as step 3.

Commit 1: `Add linear search, binary search and insertion sort`
- `src/SearchSort.h`
- `src/SearchSort.cpp`

```
git clone https://github.com/YOUR-USERNAME/BioFix.git     # skip if you already cloned it
cd BioFix
git checkout main
git pull
git checkout -b feature/search-sort
# copy the files from your folder into this BioFix folder (keep the folder names)
git add src/SearchSort.h src/SearchSort.cpp
git commit -m "Add linear search, binary search and insertion sort"
git push -u origin feature/search-sort
```

## Step 6: feature/tests

After step 5 is merged.

Commit 1: `Add test script for all menu options`
- `tests/run_tests.sh`

```
git clone https://github.com/YOUR-USERNAME/BioFix.git     # skip if you already cloned it
cd BioFix
git checkout main
git pull
git checkout -b feature/tests
# copy the files from your folder into this BioFix folder (keep the folder names)
git add tests/run_tests.sh
git commit -m "Add test script for all menu options"
git push -u origin feature/tests
```
